-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Okt 2020 pada 15.46
-- Versi server: 10.4.13-MariaDB
-- Versi PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_toko`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `nama_lengkap`, `email`) VALUES
(1, 'apan1st', 'apanganteng', 'Achmad Bagus Apandi', 'apan.xiirpl2@gmail.com'),
(2, 'apand1st', 'kepolu123', 'apandddd', 'rfapan10@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(5) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Ikan Hias'),
(2, 'Ikan Pakan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ongkir`
--

CREATE TABLE `ongkir` (
  `id_ongkir` int(5) NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `ongkir`
--

INSERT INTO `ongkir` (`id_ongkir`, `nama_kota`, `tarif`) VALUES
(1, 'Bekasi', 10000),
(2, 'Bandung', 12000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `email_pelanggan` varchar(100) NOT NULL,
  `password_pelanggan` varchar(100) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `telepon_pelanggan` varchar(100) NOT NULL,
  `alamat_pelanggan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `email_pelanggan`, `password_pelanggan`, `nama_pelanggan`, `telepon_pelanggan`, `alamat_pelanggan`) VALUES
(1, 'apan.xiirpl2@gmail.com', 'kepolu123', 'Apand', '085156507430', ''),
(3, 'rfapan10@gmail.com', 'kepolu123', 'apand', '4642646', 'asdksadjsk'),
(4, 'rfapan11@gmail.com', 'kepolu123', 'Kibo', '4654654', 'bekasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti`) VALUES
(41, 29, 'Achmad Bagus Apandi', 'BCA', 312000, '2020-10-02', '20201002174501tf.jpg'),
(42, 30, 'Achmad Bagus Apandi', 'BCA', 310000, '2020-10-02', '20201002180838tf.jpg'),
(43, 31, 'Achmad Bagus Apandi', 'BCA', 312000, '2020-10-02', '20201002182313tf.jpg'),
(44, 34, 'Achmad Bagus Apandi', 'BCA', 312000, '2020-10-02', '20201002184036tf.jpg'),
(45, 35, 'Achmad Bagus Apandi', 'BCA', 310000, '2020-10-02', '20201002184145tf.jpg'),
(46, 36, 'Achmad Bagus Apandi', 'BCA', 360000, '2020-10-02', '20201002185148tf.jpg'),
(47, 38, 'Achmad Bagus Apandi', 'BCA', 690000, '2020-10-03', '20201003134255tf.jpg'),
(48, 40, 'Achmad Bagus Apandi', 'BCA', 259000, '2020-10-04', '20201004031418Screenshot_2020-10-04-07-51-21-94.jpg'),
(49, 42, 'Achmad Bagus Apandi', 'BCA', 381000, '2020-10-04', '20201004122612Screenshot_2020-10-04-08-41-52-50.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int(11) NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `status_pembelian` varchar(100) NOT NULL DEFAULT 'Belum Bayar',
  `resi_pengiriman` varchar(50) NOT NULL,
  `totalberat` int(11) NOT NULL,
  `provinsi` varchar(255) NOT NULL,
  `kota` varchar(255) NOT NULL,
  `tipe` varchar(255) NOT NULL,
  `kodepos` varchar(255) NOT NULL,
  `ekspedisi` varchar(255) NOT NULL,
  `paket` varchar(255) NOT NULL,
  `ongkir` int(11) NOT NULL,
  `estimasi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_pelanggan`, `tanggal_pembelian`, `total_pembelian`, `alamat_pengiriman`, `status_pembelian`, `resi_pengiriman`, `totalberat`, `provinsi`, `kota`, `tipe`, `kodepos`, `ekspedisi`, `paket`, `ongkir`, `estimasi`) VALUES
(48, 1, '2020-10-04', 295000, 'asdsad', 'Belum Bayar', '', 100, 'Kalimantan Selatan', 'Hulu Sungai Utara', 'Kabupaten', '71419', 'jne', 'OKE', 45000, '5-7'),
(49, 1, '2020-10-04', 301000, 'sadsad', 'Belum Bayar', '', 100, 'Kalimantan Barat', 'Pontianak', 'Kabupaten', '78971', 'tiki', 'ECO', 51000, '4'),
(50, 3, '2020-10-04', 377000, 'sadsad', 'Belum Bayar', '', 100, 'Kalimantan Selatan', 'Kotabaru', 'Kabupaten', '72119', 'tiki', 'REG', 77000, '3'),
(51, 1, '2020-10-04', 452000, 'asdasdsad', 'Belum Bayar', '', 100, 'Kalimantan Tengah', 'Lamandau', 'Kabupaten', '74611', 'jne', 'OKE', 52000, '5-7'),
(52, 1, '2020-10-04', 355000, 'asdasd', 'Belum Bayar', '', 100, 'Kepulauan Riau', 'Kepulauan Anambas', 'Kabupaten', '29991', 'jne', 'OKE', 55000, '4-7'),
(53, 1, '2020-10-04', 418000, 'Djsjsjs', 'Belum Bayar', '', 600, 'Jawa Barat', 'Bekasi', 'Kabupaten', '17837', 'jne', 'CTCYES', 18000, '1-1'),
(54, 1, '2020-10-04', 302000, 'asdsad', 'Belum Bayar', '', 100, 'Kalimantan Tengah', 'Lamandau', 'Kabupaten', '74611', 'jne', 'OKE', 52000, '5-7'),
(55, 1, '2020-10-04', 311000, 'asdsadsa', 'Belum Bayar', '', 100, 'Kalimantan Utara', 'Bulungan (Bulongan)', 'Kabupaten', '77211', 'jne', 'OKE', 61000, '5-7');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian_produk`
--

CREATE TABLE `pembelian_produk` (
  `id_pembelian_produk` int(11) NOT NULL,
  `id_pembelian` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `berat` int(11) NOT NULL,
  `subberat` int(11) NOT NULL,
  `subharga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pembelian_produk`
--

INSERT INTO `pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`, `nama`, `harga`, `berat`, `subberat`, `subharga`) VALUES
(64, 51, 46, 1, 'Avatar Gordon', 400000, 100, 100, 400000),
(65, 52, 44, 1, 'Cupang Serit', 300000, 100, 100, 300000),
(66, 53, 50, 1, 'Ikan Mujair', 150000, 500, 500, 150000),
(67, 53, 43, 1, 'Halfmoon', 250000, 100, 100, 250000),
(68, 54, 43, 1, 'Halfmoon', 250000, 100, 100, 250000),
(69, 55, 43, 1, 'Halfmoon', 250000, 100, 100, 250000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `id_kategori` int(5) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `berat_produk` int(11) NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `stok_produk` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `id_kategori`, `nama_produk`, `harga_produk`, `berat_produk`, `foto_produk`, `deskripsi_produk`, `stok_produk`) VALUES
(43, 1, 'Halfmoon', 250000, 100, 'halfmoon.jpg', 'Ikan Cupang Jenis Halfmoon atau Kipas		', -25),
(44, 1, 'Cupang Serit', 300000, 100, 'serit.jpg', 'Ikan Cupang Jenis Serit atau Crowntail', 6),
(45, 1, 'Cupang Giant', 350000, 100, 'giant.jpg', 'Ikan Cupang Jenis Giant dengan Ukuran yg lebih besar dari jenis lainya', 9),
(46, 1, 'Avatar Gordon', 400000, 100, 'avatargordon.jpg', 'Ikan Cupang motif Avatar Gordon', 9),
(47, 2, 'Ikan Lele', 10000, 500, 'lele.jpg', 'Ikan Lele Ukuran Jumbo', 100),
(48, 2, 'Kakap Putih', 15000, 500, 'kakapputih.jpg', 'Ikan Kakap Putih', 9),
(49, 2, 'Ikan Mas', 15000, 500, 'ikanmas.jpg', 'Ikan Mas', 9),
(50, 2, 'Ikan Mujair', 150000, 500, 'mujair.jpg', 'Ikan Mujair', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk_foto`
--

CREATE TABLE `produk_foto` (
  `id_produk_foto` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `nama_produk_foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk_foto`
--

INSERT INTO `produk_foto` (`id_produk_foto`, `id_produk`, `nama_produk_foto`) VALUES
(36, 43, 'halfmoon.jpg'),
(37, 43, 'halfmoon2.jpg'),
(38, 44, 'serit.jpg'),
(39, 45, 'giant.jpg'),
(41, 46, 'avatargordon.jpg'),
(42, 47, 'lele.jpg'),
(44, 48, 'kakapputih.jpg'),
(45, 49, 'ikanmas.jpg'),
(46, 50, 'mujair.jpg'),
(49, 47, '20201003183741lele2.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(1, 'Sajal', 'sajal.agrawal1997@gmail.com', '57f231b1ec41dc6641270cb09a56f897', '8899889988', 'Indore', '100 palace colony, Indore'),
(2, 'Ram', 'ram1234@xyz.com', '57f231b1ec41dc6641270cb09a56f897', '8899889989', 'Pune', '100 palace colony, Pune'),
(3, 'Shyam', 'shyam@xyz.com', '57f231b1ec41dc6641270cb09a56f897', '8899889990', 'Bangalore', '100 palace colony, Bangalore'),
(4, 'apan1st', 'apan.xiirpl2@gmail.com', '7373025f880c37f4ebbfd4ac69953fab', '085156507430', 'Bekasi', 'Bekasi');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id_ongkir`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indeks untuk tabel `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD PRIMARY KEY (`id_pembelian_produk`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `produk_foto`
--
ALTER TABLE `produk_foto`
  ADD PRIMARY KEY (`id_produk_foto`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id_ongkir` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  MODIFY `id_pembelian_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT untuk tabel `produk_foto`
--
ALTER TABLE `produk_foto`
  MODIFY `id_produk_foto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
