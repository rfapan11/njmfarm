<?php if (isset($_SESSION["pelanggan"])): ?>
<?php 
$id_pelanggan = $_SESSION["pelanggan"]["id_pelanggan"];
$data_belanja = mysqli_query($koneksi,"SELECT * FROM pembelian WHERE id_pelanggan='$id_pelanggan'");
$riwayatbelanja = mysqli_num_rows($data_belanja); 
$nomor=0; ?>

<?php endif ?>